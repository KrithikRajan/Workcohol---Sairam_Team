import os
import uuid
from flask import Flask, render_template, request, send_from_directory
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField, IntegerField
from wtforms.validators import DataRequired
import pyttsx3  # Local TTS engine
import random

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.urandom(24)

# Directory for storing audio files
AUDIO_DIR = "static/audio/"
os.makedirs(AUDIO_DIR, exist_ok=True)

# Form class for content generation
class VideoScriptForm(FlaskForm):
    topic = StringField('Video Topic', validators=[DataRequired()])
    purpose = SelectField('Purpose', choices=[('educational', 'Educational'), ('marketing', 'Marketing'), ('storytelling', 'Storytelling')], validators=[DataRequired()])
    tone_style = SelectField('Tone & Style', choices=[('professional', 'Professional'), ('casual', 'Casual'), ('humorous', 'Humorous'), ('emotional', 'Emotional')], validators=[DataRequired()])
    target_audience = StringField('Target Audience', validators=[DataRequired()])
    word_count = IntegerField('Word Count (approx.)', validators=[DataRequired()])
    language = SelectField('Language', choices=[('en', 'English'), ('hi', 'Hindi'), ('ta', 'Tamil'), ('te', 'Telugu')], validators=[DataRequired()])
    accent = SelectField('Accent', choices=[('us', 'American'), ('uk', 'British'), ('in', 'Indian')], validators=[DataRequired()])
    gender = SelectField('Gender', choices=[('male', 'Male'), ('female', 'Female'), ('child', 'Child')], validators=[DataRequired()])
    voice_tone = SelectField('Voice Tone', choices=[('-10', 'Soft'), ('0', 'Neutral'), ('10', 'Harsh'), ('20', 'Rugged')], validators=[DataRequired()])
    submit = SubmitField('Generate Content')

# Improved function to generate offline video content
def generate_video_content(topic, purpose, tone_style, target_audience, word_count, language):
    intro_map = {
        'educational': f"Hey there! Today, we’re diving into the topic of {topic}. If you’re someone from {target_audience}, this {tone_style} session is crafted just for you.",
        'marketing': f"Are you looking to boost your results with {topic}? In this {tone_style} video, we’ll show {target_audience} exactly how to make that happen.",
        'storytelling': f"Let me tell you a story about {topic} — a tale that {target_audience} will relate to and remember.",
    }

    middle_map = {
        'educational': [
            f"{topic} plays a vital role in everyday life. From theory to real-world application, we’ll break it down into simple terms.",
            f"Whether you’re just starting out or already familiar, there’s always something new to learn about {topic}.",
            f"In fact, {topic} is one of the most powerful tools to understand how things work in the world around us."
        ],
        'marketing': [
            f"{topic} is more than just a trend — it's a solution. We’ll show you how it can transform your journey.",
            f"Brands and creators alike are tapping into {topic}, and you don’t want to miss the wave.",
            f"Understanding {topic} can give you the competitive edge you need in today’s marketplace."
        ],
        'storytelling': [
            f"{topic} didn’t always have the attention it has now. There was a time when even {target_audience} overlooked it — until something changed.",
            f"Let’s rewind the clock and explore how {topic} became so relevant, especially for people like you.",
            f"The story of {topic} is one of transformation, where it grew to become an essential part of our lives."
        ]
    }

    outro_map = {
        'educational': f"So, whether you're a beginner or enthusiast, keep exploring {topic} and stay curious!",
        'marketing': f"Don’t forget — {topic} might just be the key to your next big move.",
        'storytelling': f"And that’s how {topic} became a part of our story. What’s your take on it?"
    }

    intro = intro_map.get(purpose, f"This video is about {topic}.")
    middle = random.sample(middle_map.get(purpose, []), min(3, len(middle_map.get(purpose, []))))
    outro = outro_map.get(purpose, "")

    content = f"{intro}\n\n" + "\n\n".join(middle) + f"\n\n{outro}"

    # Add more content until word count is met
    current_word_count = len(content.split())
    while current_word_count < word_count:
        # Add a random paragraph from the selected purpose to avoid repetition
        content += "\n\n" + random.choice(middle_map.get(purpose, []))
        current_word_count = len(content.split())

    return content

# Generate audio with pyttsx3 (offline TTS engine)
def generate_audio(text, language, accent, gender, voice_tone):
    engine = pyttsx3.init()
    voices = engine.getProperty('voices')

    # Basic voice selection (pyttsx3 depends on installed voices)
    voice_map = {
        'male': 'english-us',
        'female': 'english-us',
        'child': 'english-us'
    }

    selected_voice = voice_map.get(gender, 'english-us')
    engine.setProperty('voice', selected_voice)
    engine.setProperty('rate', 150)
    engine.setProperty('volume', 1)

    audio_filename = f"{uuid.uuid4()}.mp3"
    audio_path = os.path.join(AUDIO_DIR, audio_filename)

    engine.save_to_file(text, audio_path)
    engine.runAndWait()
    return audio_filename

# Route to generate content and audio
@app.route('/', methods=['GET', 'POST'])
def index():
    form = VideoScriptForm()
    content_text = None
    audio_file = None

    if form.validate_on_submit():
        topic = form.topic.data
        content_text = generate_video_content(topic, form.purpose.data, form.tone_style.data, form.target_audience.data, form.word_count.data, form.language.data)

        audio_filename = generate_audio(content_text, form.language.data, form.accent.data, form.gender.data, form.voice_tone.data)

        return render_template('index.html', form=form, content_text=content_text, audio_file=audio_filename)

    return render_template('index.html', form=form, content_text=content_text, audio_file=None)

# Route to download the audio
@app.route('/download_audio/<filename>')
def download_audio(filename):
    return send_from_directory(AUDIO_DIR, filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
