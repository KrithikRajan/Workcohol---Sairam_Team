import openai
from flask import Flask, render_template, request, send_from_directory
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField, IntegerField
from wtforms.validators import DataRequired
import os
from dotenv import load_dotenv
import edge_tts
import asyncio
import uuid

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY')

# OpenAI API key
openai.api_key = os.getenv('OPENAI_API_KEY')

# Directory for storing audio files
AUDIO_DIR = "static/audio/"
os.makedirs(AUDIO_DIR, exist_ok=True)

# Form class for content generation
class VideoScriptForm(FlaskForm):
    topic = StringField('Video Topic', validators=[DataRequired()])
    purpose = SelectField('Purpose', choices=[('educational', 'Educational'), ('marketing', 'Marketing'), ('storytelling', 'Storytelling')], validators=[DataRequired()])
    tone_style = SelectField('Tone & Style', choices=[('professional', 'Professional'), ('casual', 'Casual'), ('humorous', 'Humorous'), ('emotional', 'Emotional')], validators=[DataRequired()])
    target_audience = StringField('Target Audience', validators=[DataRequired()])
    word_count = IntegerField('Word Count (approx.)', validators=[DataRequired()])
    language = SelectField('Language', choices=[('en', 'English'), ('hi', 'Hindi'), ('ta', 'Tamil'), ('te', 'Telugu')], validators=[DataRequired()])
    accent = SelectField('Accent', choices=[('us', 'American'), ('uk', 'British'), ('in', 'Indian')], validators=[DataRequired()])
    gender = SelectField('Gender', choices=[('male', 'Male'), ('female', 'Female'), ('child', 'Child')], validators=[DataRequired()])
    voice_tone = SelectField('Voice Tone', choices=[('-10', 'Soft'), ('0', 'Neutral'), ('10', 'Harsh'), ('20', 'Rugged')], validators=[DataRequired()])
    submit = SubmitField('Generate Content')

# Generate structured content using GPT-4
def generate_video_content(topic, purpose, tone_style, target_audience, word_count, language):
    language_map = {
        'en': 'English',
        'hi': 'Hindi',
        'ta': 'Tamil',
        'te': 'Telugu'
    }
    selected_language = language_map.get(language, 'English')
    
    prompt = f"""
    Generate a {word_count}-word structured video content in {selected_language}.
    Topic: {topic}
    Purpose: {purpose}
    Tone & Style: {tone_style}
    Target Audience: {target_audience}
    
    The content should be engaging, well-structured, and informative. 
    It should include an introduction, key points, and a conclusion. Avoid using scene descriptions.
    """
    response = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=[{"role": "system", "content": "You are a content writer."},
              {"role": "user", "content": prompt}],
    max_tokens=1000,  # Reduce max tokens for faster responses
    temperature=0.7
)

    
    return response['choices'][0]['message']['content'].strip()
async def generate_audio(text, language, accent, gender, voice_tone):
    voice_mapping = {
        ('male', 'en', 'us'): 'en-US-GuyNeural',
        ('female', 'en', 'us'): 'en-US-JennyNeural',
        ('child', 'en', 'us'): 'en-US-ChristopherNeural',
        ('male', 'en', 'uk'): 'en-GB-RyanNeural',
        ('female', 'en', 'uk'): 'en-GB-SoniaNeural',
        ('child', 'en', 'uk'): 'en-GB-ThomasNeural',
        ('male', 'en', 'in'): 'en-IN-PrabhatNeural',
        ('female', 'en', 'in'): 'en-IN-NeerjaNeural',
        ('child', 'en', 'in'): 'en-IN-KartikNeural',
        ('male', 'hi', 'in'): 'hi-IN-MadhurNeural',
        ('female', 'hi', 'in'): 'hi-IN-SwaraNeural',
        ('child', 'hi', 'in'): 'hi-IN-KabirNeural',
        ('male', 'ta', 'in'): 'ta-IN-ValluvarNeural',
        ('female', 'ta', 'in'): 'ta-IN-PallaviNeural',
        ('child', 'ta', 'in'): 'ta-IN-KumarNeural',
        ('male', 'te', 'in'): 'te-IN-MohanNeural',
        ('female', 'te', 'in'): 'te-IN-ShrutiNeural',
        ('child', 'te', 'in'): 'te-IN-ChittiNeural'
    }

    voice = voice_mapping.get((gender, language, accent), 'en-US-GuyNeural')
    audio_filename = f"{uuid.uuid4()}.mp3"
    audio_path = os.path.join(AUDIO_DIR, audio_filename)

    try:
        voice_tone_int = int(voice_tone)
        valid_voice_tone = f"+{voice_tone_int}%" if voice_tone_int >= 0 else f"{voice_tone_int}%"
    except ValueError:
        valid_voice_tone = "+0%"

    print(f"Generating audio with voice: {voice}, rate: {valid_voice_tone}")

    try:
        communicate = edge_tts.Communicate(text, voice, rate=valid_voice_tone)
        await communicate.save(audio_path)
        return audio_filename
    except edge_tts.exceptions.NoAudioReceived:
        print("Error: No audio received from Edge TTS.")
        return None



# Route to generate content and audio
@app.route('/', methods=['GET', 'POST'])
def index():
    form = VideoScriptForm()
    content_text = None
    audio_file = None

    if form.validate_on_submit():
        topic = form.topic.data
        content_text = generate_video_content(topic, form.purpose.data, form.tone_style.data, form.target_audience.data, form.word_count.data, form.language.data)
        
        # Run async function properly
        audio_filename = asyncio.run(generate_audio(content_text, form.language.data, form.accent.data, form.gender.data, form.voice_tone.data))

        
        return render_template('index.html', form=form, content_text=content_text, audio_file=audio_filename)

    return render_template('index.html', form=form, content_text=content_text, audio_file=None)

# Route to download the audio
@app.route('/download_audio/<filename>')
def download_audio(filename):
    return send_from_directory(AUDIO_DIR, filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
